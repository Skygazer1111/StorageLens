import{r as e}from"./rolldown-runtime-QTnfLwEv.js";import"./modulepreload-polyfill-Dezn_h7o.js";import{a as t,c as n,o as r,t as i}from"./useExtensionSettings-RDo7KkM3.js";var a=e(n(),1),o=r(),s=t();function c({checked:e,disabled:t=!1,label:n,description:r,isDark:i=!0,onChange:a}){return(0,s.jsxs)(`label`,{onClick:()=>!t&&a(!e),className:`flex items-start justify-between gap-3 rounded-lg border px-3 py-2.5 transition-colors ${t?`cursor-not-allowed opacity-50`:`cursor-pointer`} ${i?`border-surface-border bg-surface-raised/50 hover:border-surface-border/80`:`border-slate-200 bg-white hover:border-slate-300`}`,children:[(0,s.jsxs)(`span`,{className:`min-w-0 flex-1`,children:[(0,s.jsx)(`span`,{className:`block text-sm font-medium ${i?`text-gray-100`:`text-slate-900`}`,children:n}),r&&(0,s.jsx)(`span`,{className:`mt-0.5 block text-xs leading-relaxed ${i?`text-gray-400`:`text-slate-500`}`,children:r})]}),(0,s.jsx)(`span`,{role:`presentation`,className:`pointer-events-none relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition-colors ${e?`bg-accent`:i?`bg-surface-border`:`bg-slate-300`}`,children:(0,s.jsx)(`span`,{className:`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${e?`translate-x-5`:`translate-x-0`}`})})]})}var l=`# Privacy Policy

**Last updated:** June 2026

StorageLens is a developer tool for inspecting and editing browser storage on pages you choose to debug. Your privacy is important to us.

## Summary

- **All data stays on your device.** StorageLens does not send your storage data, cookies, tokens, or snapshots to any remote server.
- **No analytics or tracking** are included in this extension.
- **No accounts** are required.

## What StorageLens accesses

When you use StorageLens, it may read and write:

- **localStorage** and **sessionStorage** on the inspected page
- **Cookies** for the inspected origin (via the Chrome cookies API)
- **IndexedDB** databases on the inspected page

This access only occurs when you open DevTools and use the StorageLens panel on a page you are debugging, or when live tracking is enabled in settings.

## What StorageLens stores locally

The extension may save the following in **chrome.storage.local** on your device:

- Extension settings (theme, toggles, poll interval)
- Snapshots you explicitly capture
- Theme preference

Snapshots and settings never leave your browser unless you export a snapshot file yourself.

## Permissions

| Permission | Why we need it |
|------------|----------------|
| \`cookies\` | Read and edit cookies for the inspected origin |
| \`storage\` | Save settings and snapshots locally |
| \`activeTab\` | Resolve the current tab context |
| \`<all_urls>\` | Access storage on any origin you inspect as a developer |

## Third parties

StorageLens does not integrate third-party analytics, advertising, or cloud sync in v1.

## Children

StorageLens is intended for developers and is not directed at children under 13.

## Changes

We may update this policy as the extension evolves. Material changes will be reflected in the extension options page.

## Contact

For privacy questions about StorageLens, open an issue or contact the maintainer through the project repository.`,u=`# Terms of Service

**Last updated:** June 2026

By installing or using StorageLens ("the Extension"), you agree to these Terms of Service.

## 1. Purpose

StorageLens is a **developer debugging tool**. It is designed to help software developers inspect and modify browser storage during development and testing.

## 2. Acceptable use

You agree to use StorageLens only:

- On pages and applications you own, maintain, or have permission to debug
- In compliance with applicable laws and website terms

You must not use StorageLens to access, extract, or modify data on systems you are not authorized to debug.

## 3. Data modification

StorageLens can **edit and delete** localStorage, sessionStorage, cookies, and IndexedDB records. Changes are applied directly to the page under inspection. You are solely responsible for any data loss or application breakage caused by edits you make.

## 4. No warranty

THE EXTENSION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.

## 5. Limitation of liability

To the maximum extent permitted by law, the authors and contributors of StorageLens shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of data, profits, or goodwill, arising from your use of the Extension.

## 6. JWT and security

StorageLens can decode JWT payloads for debugging. It does **not** verify signatures. Do not treat decoded JWT output as trusted security validation.

## 7. Updates

We may update the Extension or these Terms. Continued use after updates constitutes acceptance of the revised Terms.

## 8. Termination

You may stop using StorageLens at any time by disabling or uninstalling the Extension.

## 9. Governing law

These Terms are governed by the laws applicable in your jurisdiction, without regard to conflict-of-law principles.

## 10. Contact

For questions about these Terms, contact the maintainer through the project repository.`;function d(){let e=window.location.hash.replace(`#`,``);return e===`privacy`||e===`terms`?e:`settings`}function f({content:e,isDark:t}){let n=e.split(`
`);return(0,s.jsx)(`article`,{className:`prose-sm max-w-none space-y-3 text-sm leading-relaxed ${t?`text-gray-300`:`text-slate-700`}`,children:n.map((e,n)=>e.startsWith(`# `)?(0,s.jsx)(`h1`,{className:`text-2xl font-bold ${t?`text-white`:`text-slate-900`}`,children:e.slice(2)},n):e.startsWith(`## `)?(0,s.jsx)(`h2`,{className:`mt-6 text-lg font-semibold ${t?`text-gray-100`:`text-slate-900`}`,children:e.slice(3)},n):e.startsWith(`| `)?(0,s.jsx)(`p`,{className:`font-mono text-xs`,children:e},n):e.startsWith(`- `)?(0,s.jsx)(`li`,{className:`ml-4 list-disc`,children:e.slice(2)},n):e.trim()?(0,s.jsx)(`p`,{children:e},n):(0,s.jsx)(`div`,{className:`h-2`},n))})}function p(){let{settings:e,isLoading:t,updateSettings:n}=i(),[r,o]=(0,a.useState)(d),p=e?.theme!==`light`;(0,a.useEffect)(()=>{let e=()=>o(d());return window.addEventListener(`hashchange`,e),()=>window.removeEventListener(`hashchange`,e)},[]);let m=e=>{o(e)};if((0,a.useEffect)(()=>{let e=r===`settings`?``:`#${r}`;if(window.location.hash!==e){if(r===`settings`){history.replaceState(null,``,`${window.location.pathname}${window.location.search}`);return}window.location.hash=r}},[r]),t||!e)return(0,s.jsx)(`div`,{className:`flex min-h-screen items-center justify-center ${p?`bg-surface text-gray-400`:`bg-slate-50 text-slate-500`}`,children:`Loading…`});let h=!e.enabled,g=p?`bg-surface text-gray-100`:`bg-slate-50 text-slate-900`,_=p?`border-surface-border bg-surface-raised/40`:`border-slate-200 bg-white`,v=p?`text-gray-400 hover:text-white`:`text-slate-500 hover:text-slate-900`;return(0,s.jsxs)(`div`,{className:`min-h-screen ${g}`,children:[(0,s.jsxs)(`header`,{className:`border-b ${p?`border-surface-border`:`border-slate-200`}`,children:[(0,s.jsxs)(`div`,{className:`mx-auto flex max-w-3xl items-center justify-between px-6 py-5`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`h1`,{className:`text-xl font-semibold`,children:`StorageLens`}),(0,s.jsx)(`p`,{className:`text-sm ${p?`text-gray-400`:`text-slate-500`}`,children:`Extension settings & legal`})]}),(0,s.jsx)(`div`,{className:`flex gap-2`,children:[`dark`,`light`].map(t=>(0,s.jsx)(`button`,{type:`button`,onClick:()=>void n({theme:t}),className:`rounded-md border px-2.5 py-1 text-xs capitalize ${e.theme===t?`border-accent text-accent`:p?`border-surface-border text-gray-400`:`border-slate-200 text-slate-500`}`,children:t},t))})]}),(0,s.jsx)(`nav`,{className:`mx-auto flex max-w-3xl gap-6 border-t px-6 ${p?`border-surface-border`:`border-slate-200`}`,children:[[`settings`,`Settings`],[`privacy`,`Privacy Policy`],[`terms`,`Terms of Service`]].map(([e,t])=>(0,s.jsx)(`button`,{type:`button`,onClick:()=>m(e),className:`border-b-2 py-3 text-sm font-medium transition-colors ${r===e?`border-accent text-accent`:`border-transparent ${v}`}`,children:t},e))})]}),(0,s.jsxs)(`main`,{className:`mx-auto max-w-3xl px-6 py-8`,children:[r===`settings`&&(0,s.jsxs)(`div`,{className:`space-y-6`,children:[(0,s.jsx)(`section`,{className:`rounded-xl border p-5 ${_}`,children:(0,s.jsx)(c,{checked:e.enabled,label:`Extension enabled`,description:`Master switch for StorageLens. When disabled, live tracking and background helpers pause.`,isDark:p,onChange:e=>void n({enabled:e})})}),(0,s.jsxs)(`section`,{className:`space-y-3 rounded-xl border p-5 ${_} ${h?`opacity-40`:``}`,children:[(0,s.jsx)(`h2`,{className:`text-sm font-semibold`,children:`Live tracking`}),(0,s.jsx)(c,{checked:e.liveTrackingEnabled,disabled:h,label:`Watch storage changes`,description:`Poll localStorage, sessionStorage, and cookies while the DevTools panel is open.`,isDark:p,onChange:e=>void n({liveTrackingEnabled:e})}),(0,s.jsx)(c,{checked:e.liveIdbEnabled,disabled:h,label:`Live IndexedDB`,description:`Diff the selected object store on an interval (best-effort, first 200 records).`,isDark:p,onChange:e=>void n({liveIdbEnabled:e})}),(0,s.jsxs)(`label`,{className:`block text-sm ${p?`text-gray-300`:`text-slate-700`}`,children:[(0,s.jsx)(`span`,{className:`mb-1 block font-medium`,children:`Poll interval (seconds)`}),(0,s.jsx)(`input`,{type:`number`,min:1,max:30,step:.5,disabled:h,value:e.pollIntervalMs/1e3,onChange:e=>{let t=Number(e.target.value);Number.isFinite(t)&&n({pollIntervalMs:Math.min(3e4,Math.max(1e3,t*1e3))})},className:`w-full rounded-lg border px-3 py-2 text-sm ${p?`border-surface-border bg-surface text-gray-100`:`border-slate-300 bg-white text-slate-900`}`})]})]}),(0,s.jsxs)(`section`,{className:`rounded-xl border p-5 ${_}`,children:[(0,s.jsx)(`h2`,{className:`mb-2 text-sm font-semibold`,children:`Using StorageLens`}),(0,s.jsx)(`p`,{className:`text-sm leading-relaxed ${p?`text-gray-400`:`text-slate-600`}`,children:`Click the StorageLens toolbar icon to open the side panel and inspect storage on the active tab. The full workspace is also available in DevTools under the StorageLens tab.`})]})]}),r===`privacy`&&(0,s.jsx)(`div`,{className:`rounded-xl border p-6 ${_}`,children:(0,s.jsx)(f,{content:l,isDark:p})}),r===`terms`&&(0,s.jsx)(`div`,{className:`rounded-xl border p-6 ${_}`,children:(0,s.jsx)(f,{content:u,isDark:p})})]})]})}(0,o.createRoot)(document.getElementById(`root`)).render((0,s.jsx)(a.StrictMode,{children:(0,s.jsx)(p,{})}));